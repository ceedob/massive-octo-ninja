import entity, pygame
from pygame.locals import * 

class player(entity.entity):

	def __init__(self):
		pass
		
	height = 50
	width = 45
	y= 300
	
	accel = 1
	
	window = 0
	
	left, right = False, False
	side, up = 0, 0 #up is down
	
	jumping = 0
	
	on=False
	
	friction=0.85
	
	def tick(self, entities):
		
		if self.jumping > 0:
			self.jumping +=-1
			self.up+=-self.accel*3
		else:
			self.up += self.accel
			
		if self.left == True:
			self.side += -self.accel
		if self.right == True:
			self.side += self.accel
			
		if self.y > self.window and self.up > 0:
			self.up = 0
		
		allowedDown = True
		for e in entities:
			if self.y+self.height/2 < e.y and self.y + self.up + self.height/2 > e.y - self.up and self.x > e.x and self.x < e.x+e.width:# and e.impassable==True :
				allowedDown = False
				self.up = 0
				self.on = True
			else:
				self.on = False
		self.x += self.side
		self.y += self.up
		
		self.side *=self.friction
	def jump(self):
		if self.jumping == 0 and self.up==0:
			self.jumping = 6
		
		
	def draw(self, window):
		if self.on:
			pygame.draw.rect(window,(0,255,255),(self.x-self.width/2, self.y-self.height/2, self.width, self.height))
		else:
			pygame.draw.rect(window,(0,0,255),(self.x-self.width/2, self.y-self.height/2, self.width, self.height))
		
		#(player["x"],window.get_height()*3/4-player["h"]-player["alt"] ,player["w"],player["h"])
		pass
		