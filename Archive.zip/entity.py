class entity (object):
	x = 0
	y = 0
	speed = 0
		
	height = 0
	width = 0
	def __init__(self):
		pass
