import entity, pygame
class platform (entity.entity):
	def __init__(self):
		pass
		
	impassable = True
	def draw(self, window):
		pygame.draw.rect(window,(0,255,0),(self.x, self.y, self.width, self.height))