import pygame, sys,os, math
import Player, environment
from pygame.locals import * 
from pygame.draw import *

pygame.init()
window = pygame.display.set_mode((0,0),pygame.FULLSCREEN|pygame.HWSURFACE) 
fpsClock = pygame.time.Clock()

player = Player.player()
player.window = window.get_height()

entities = [environment.platform(),environment.platform(),environment.platform()]
entities[0].x = 100
entities[0].y = 300
entities[0].width = 200
entities[0].height = 20
entities[1].x = 300
entities[1].y = 500
entities[1].width = 400
entities[1].height = 20
entities[2].x = 100
entities[2].y = 700
entities[2].width = 100
entities[2].height = 20
def input(events): 
   global player

   for event in events: 
      if event.type == QUIT: 
         sys.exit(0)
         
      elif event.type == KEYDOWN:
        if event.key == K_ESCAPE:
         sys.exit(0)
         
        if event.key == K_a or event.key == K_LEFT:
         player.left = True
        elif event.key == K_d or event.key == K_RIGHT:
         player.right = True
        elif event.key == K_w or event.key == K_UP:
          player.jump()
           
      elif event.type == KEYUP:
         if event.key == K_a or event.key == K_LEFT:
          player.left=False
         elif event.key == K_d or event.key == K_RIGHT:
          player.right=False
          
      else:
      	pass 
         #print event 

while True: 
	
	window.fill((99,185,255))
	
	player.tick(entities)
	
	
	for e in entities:
		e.draw(window)
	
	player.draw(window)
			
	input(pygame.event.get())  
	pygame.display.update()
	fpsClock.tick(30)
	
